#!/usr/bin/perl
use strict;
my $TemperatureToday=33;
my $TemperatureYesterday=30;

print "\nThe temperature difference is: ".$TemperatureToday-$TemperatureYesterday."\n";

print "Dividing 27 by 4 leaves: ". 27%4;

