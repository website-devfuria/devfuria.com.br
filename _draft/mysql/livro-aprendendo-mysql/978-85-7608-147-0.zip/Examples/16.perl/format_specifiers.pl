#!/usr/bin/perl
printf("\n%15s", "hello");
printf("\n%-15s", "hello");

printf("\n%4.2f", 1/3);
printf("\n%.2f", 1/3);

printf("\n%20d", 1/3);

printf("\nTotal:   %10.2f", 13);
printf("\nAverage: %10.2f", 13/2);

