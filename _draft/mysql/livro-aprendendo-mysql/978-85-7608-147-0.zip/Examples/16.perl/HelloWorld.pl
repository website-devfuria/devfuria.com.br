#!/usr/bin/perl
print("Hello, world!\n");
print("Hello,\nworld!\n1\t2\t3\n");
#print("Hello,\nworld!\n1\t2\t3\nThis is a backslash (\\), and this is a double quote (\") '\n");
#print('Hello,\nworld!\n1\t2\t3\nThis is a backslash (\\), and this is a double quote (\") \'\n');
 
