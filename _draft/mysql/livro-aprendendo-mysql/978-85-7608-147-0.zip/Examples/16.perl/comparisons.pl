#!/usr/bin/perl
use strict;
my $TemperatureToday=33;

print "Equal to 33:                 [". ($TemperatureToday==33). "]\n";
print "Not equal to 33:             [". ($TemperatureToday!=33). "]\n";
print "Less than 33:                [". ($TemperatureToday <33). "]\n";
print "Greater than 33:             [". ($TemperatureToday >33). "]\n";
print "Less than or equal to 33:    [". ($TemperatureToday<=33). "]\n";
print "Greater than or equal to 33: [". ($TemperatureToday>=33). "]\n";

