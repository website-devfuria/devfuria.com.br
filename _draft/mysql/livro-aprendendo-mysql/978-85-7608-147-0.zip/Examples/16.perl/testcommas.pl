#!/usr/bin/perl
my $var=3;
print "1 ". $var. " 2";
