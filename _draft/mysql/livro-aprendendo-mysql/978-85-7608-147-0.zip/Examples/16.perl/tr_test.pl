#!/usr/bin/perl
tr();
