#!/usr/bin/perl
use strict;

my $Value="1E3";

printf("The value %s is %d", $Value, $Value);
