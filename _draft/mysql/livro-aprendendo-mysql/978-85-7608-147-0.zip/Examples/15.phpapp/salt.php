<?php
echo crypt("My secret password", "ss");
echo "\n";
echo crypt("My secret password", "st");
echo "\n";
?>
