<?php
	print "Added artist: ".$_GET['artist_name'];
?>
