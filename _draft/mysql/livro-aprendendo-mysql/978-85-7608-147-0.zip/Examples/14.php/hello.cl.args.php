#!/usr/bin/php
<?php
if($argc==2)
	echo "Hello, {$argv[1]}!\n";
else
	echo "Syntax: {$argv[0]} [Your First Name]\n";
?>
