<?php
{
	$var=5;
}
echo $var
?>
