<!DOCTYPE HTML PUBLIC
"-//W3C//DTD HTML 4.0 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd" >
<html>
	<head>
		<title>Saying hello</title>
	</head>
	<body>
		<?php
		echo "Hello, {$_GET["username"]}";
		?>
	</body>
</html>
