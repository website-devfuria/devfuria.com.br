<?php
                printf("%10d x %10d = %10.1f %s\n", 6, "inches", 2.54, 6*2.54);
?>
