#!/usr/bin/php
<?php
	echo "Hello, world\n";
?>
