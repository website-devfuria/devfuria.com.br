                <html>
                    <body>
                        <pre>
                            <?php
                            print $_GET["artist"] . "\n";
                            print $_GET["album"];
                            ?>
                        </pre>
                    </body>
                </html>
