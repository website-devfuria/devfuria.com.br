#!/usr/bin/perl
print "Content-type: text/html; charset=UTF-8\n\n";

print "
<html>
    <title>My first Perl CGI script</title>
    <body>
	<b>Hello, World!</b><br />
	This is <b>very</b> interesting!
    </body>
</html>
";
