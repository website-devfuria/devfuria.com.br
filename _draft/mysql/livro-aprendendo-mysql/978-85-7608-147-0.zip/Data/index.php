<?php header("Location: http://learningmysql.com/"); ?>
