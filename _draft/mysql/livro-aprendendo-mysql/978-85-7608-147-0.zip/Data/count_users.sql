USE mysql;
SELECT COUNT(*) FROM user;
